#include <sqlpp11/sqlpp11.h>

int main()
{
}
